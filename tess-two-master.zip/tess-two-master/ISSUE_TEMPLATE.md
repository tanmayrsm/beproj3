Summary:



Steps to reproduce the issue:

1. 
2. 
3.

Expected result:



Actual result:



Tess-two version:



Android version:



Phone/device model:



Phone/device architecture (armeabi, armeabi-v7a, x86, mips, arm64-v8a, x86_64, mips64):



Link to training data used:



Link to image used as input:




